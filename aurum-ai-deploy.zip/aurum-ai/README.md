# AURUM AI — Gold Market Intelligence Prototype

A responsive front-end prototype for a commercial XAU/USD intelligence platform.

## Run locally

Open `index.html` in a modern browser. For a local web server, run:

```bash
python3 -m http.server 8000
```

Then visit http://localhost:8000.

## What's included

- Overview dashboard with illustrative gold chart and macro-impact monitor
- News intelligence feed with confirmed / developing / rumour filters
- Source-quality framework and gold-impact explanations
- Fundamental + technical analysis pages
- Conditional trade-plan layout and no-trade logic concept
- Economic calendar, daily briefing, performance lab
- Data-provider connection checklist
- Responsive desktop and mobile navigation

## Important prototype limitations

All displayed prices, chart movements, headlines, scores, events and trade levels are illustrative demo content. No live API is connected. The app does not provide executable trading signals and must not be used to place trades.

## Production architecture (next build stage)

Recommended structure:

- Front end: Next.js + TypeScript
- API/backend: Python FastAPI or Next.js server routes
- Database: PostgreSQL / Supabase
- Background jobs: scheduled polling + queue workers
- AI: OpenAI Responses API with structured outputs and source-grounded analysis
- X: X API recent search initially; streaming/access tier to be confirmed with X
- News: licensed financial-news API with timestamp/source metadata
- Calendar: licensed economic-calendar provider
- Price feed: broker-matched XAU/USD quote and OHLC feed
- Alerts: email + web push, later native mobile push

### Non-negotiable data rules

1. Preserve original source URL, publisher/account, published timestamp, observed timestamp and content hash.
2. Keep event time separate from post/article time.
3. Label X/social posts as unverified leads until corroborated; platform verification badges do not prove a claim is true.
4. Store rumours separately from confirmed facts and never silently upgrade confidence.
5. Deduplicate syndicated/repeated stories and cluster reports about the same event.
6. Compare actual macro releases with consensus and previous values.
7. Assess gold through USD, real yields, nominal yields, Fed expectations, risk sentiment and positioning; do not assume one-way relationships.
8. Generate entries only from current broker-matched prices and explicit technical triggers; otherwise return NO TRADE.
9. Log every input snapshot, model version, decision, entry/exit and outcome for point-in-time evaluation.
10. Keep API secrets on the server, never in browser JavaScript.

## Initial provider research

- X API docs: https://developer.x.com/en/docs
- OpenAI API docs: https://developers.openai.com/api/docs
- MarketNewsAPI docs: https://marketnewsapi.com/docs
- Trading Economics streaming calendar: https://docs.tradingeconomics.com/economic_calendar/streaming/
- Twelve Data docs: https://twelvedata.com/docs
- Supabase docs: https://supabase.com/docs

Before commercial launch, confirm provider pricing, latency, redistribution rights, data retention rights and financial-services regulatory obligations in the intended markets.
