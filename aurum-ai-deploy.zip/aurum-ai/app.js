const demoNews = [
 {time:'21:32 UTC',status:'developing',level:'high',category:'US Politics',source:'X / social monitoring concept',title:'White House policy comments draw attention across markets',summary:'A hypothetical developing political headline. The platform would preserve the original post, author, post time and link, then seek confirmation from an official statement or independent newsroom.',impact:'Potential gold channel: changes to fiscal, trade or geopolitical expectations may influence the dollar, Treasury yields and safe-haven demand. Direction is not assumed.',grade:'C',statusText:'Developing · uncorroborated'},
 {time:'20:58 UTC',status:'confirmed',level:'high',category:'Federal Reserve',source:'Federal Reserve · example source record',title:'Fed communication remains a key driver for rate expectations',summary:'Illustrative confirmed-event record showing how an official central-bank statement would be stored. This is not a claim that a new statement was released today.',impact:'Potential gold channel: changes in expected policy rates can affect real yields and the opportunity cost of holding non-yielding gold.',grade:'A',statusText:'Confirmed · primary-source example'},
 {time:'20:21 UTC',status:'rumour',level:'medium',category:'Geopolitics',source:'Unverified social claim · example',title:'Unverified claims circulate about a possible regional escalation',summary:'This sample demonstrates how a rumour is isolated from confirmed reporting. No factual assertion is being made about a current conflict or event.',impact:'Potential gold channel: a verified escalation could increase safe-haven demand, but the market response depends on scale, duration, oil, the dollar and yields.',grade:'D',statusText:'Unverified · do not treat as fact'},
 {time:'19:46 UTC',status:'confirmed',level:'medium',category:'US Economy',source:'US government release · example source record',title:'Economic data surprise should be compared with consensus',summary:'An example macro record. In production, actual, forecast and previous values would be captured alongside the release timestamp and source document.',impact:'Potential gold channel: stronger or weaker data can alter expected Fed policy. The surprise versus consensus matters more than the headline number alone.',grade:'A',statusText:'Confirmed · primary-source example'},
 {time:'18:55 UTC',status:'developing',level:'medium',category:'Dollar & Bonds',source:'Market data monitor · illustrative',title:'Treasury yields and dollar direction show mixed signals',summary:'Sample cross-asset alert. A production system would calculate changes in DXY, nominal yields and real yields over consistent windows.',impact:'Conflicting drivers: rising real yields and a stronger dollar can pressure gold, while falling yields and dollar weakness can support it.',grade:'B',statusText:'Developing · data validation required'},
 {time:'17:40 UTC',status:'confirmed',level:'medium',category:'Geopolitics',source:'Official statement · example source record',title:'Sanctions policy remains on the geopolitical watchlist',summary:'Illustrative example of an official policy item that could affect risk sentiment, trade flows or energy markets.',impact:'Gold impact is conditional. The engine would assess whether the measure changes perceived tail risk or produces a stronger dollar response.',grade:'A',statusText:'Confirmed · primary-source example'},
 {time:'16:12 UTC',status:'rumour',level:'low',category:'US Politics',source:'Anonymous account · example',title:'Speculation about a possible policy announcement',summary:'Low-confidence social chatter. The system should avoid amplifying it unless independent evidence emerges.',impact:'No directional gold conclusion. Monitor for an attributable statement or reputable reporting.',grade:'D',statusText:'Unverified · low confidence'},
 {time:'14:30 UTC',status:'confirmed',level:'high',category:'US Economy',source:'Economic calendar · example source record',title:'High-impact US data release window',summary:'A sample calendar item showing the fields used for scheduled events: consensus, previous, actual, release time and surprise.',impact:'Potential gold channel: assess the data surprise, initial dollar and yield reaction, then whether gold accepts or rejects the move.',grade:'A',statusText:'Confirmed schedule · sample'}
];
const events=[['18 NOV','13:30','US housing / activity data','Medium impact'],['19 NOV','13:30','US labour-market release','High impact'],['20 NOV','15:00','Fed speaker watch','Medium impact'],['25 NOV','13:30','US inflation-related release','High impact'],['02 DEC','19:00','FOMC minutes watch','High impact']];
const drivers=[['US dollar (DXY)','Bullish for gold','-74','A weaker dollar can support USD-denominated gold.'],['US real yields','Bullish for gold','-42','Lower real yields reduce the opportunity cost of holding gold.'],['Fed expectations','Bullish for gold','+66','More dovish rate expectations can support gold.'],['Geopolitical risk','Mixed','+51','Safe-haven demand is possible, but not automatic.'],['Positioning','Unknown','—','Requires reliable positioning data and context.']];
let news = [...demoNews];
const priority=document.getElementById('priorityNews'), full=document.getElementById('fullNews');
let liveStoryIds = new Set();
let alertsEnabled = false;
const esc = (v='') => String(v).replace(/[&<>\"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;',"'":'&#39;'}[c]));
function badge(n){return `<span class="severity ${n.level}">${n.level.toUpperCase()}</span>`}
function renderPriority(){priority.innerHTML=news.slice(0,4).map(n=>`<div class="news-row"><div class="news-time">${esc(n.time)}</div><div><b>${esc(n.title)}</b><small>${esc(n.category)} · ${esc(n.statusText)}</small></div>${badge(n)}</div>`).join('')}
function renderNews(){const f=document.querySelector('#newsFilters .selected')?.dataset.filter||'all';const c=document.getElementById('categoryFilter').value;const filtered=news.filter(n=>(f==='all'||n.status===f)&&(c==='all'||n.category===c));full.innerHTML=filtered.length?filtered.map(n=>`<article class="news-card"><div class="news-card-top">${badge(n)}<span class="tag neutral">${esc(n.category)}</span><span class="tag neutral">SOURCE GRADE ${esc(n.grade)}</span></div><h3>${esc(n.title)}</h3><p>${esc(n.summary)}</p><div class="news-meta"><span>${esc(n.time)}</span><span class="source">${esc(n.source)}</span><span>${esc(n.statusText)}</span></div><div class="impact-note"><b>Gold relevance:</b> ${esc(n.impact)}</div>${n.url?`<p><a href="${esc(n.url)}" target="_blank" rel="noopener noreferrer">Read original report ↗</a></p>`:''}</article>`).join(''):'<p class="sub" style="padding:22px 0">No items match these filters.</p>'}
function renderEvents(){document.getElementById('upcomingEvents').innerHTML=events.slice(0,3).map(e=>`<div class="event-row"><div class="event-date"><div><b>${e[0].split(' ')[0]}</b><br>${e[0].split(' ')[1]}</div></div><div><b>${e[2]}</b><small>${e[1]} UTC · ${e[3]}</small></div></div>`).join('');document.getElementById('calendarEvents').innerHTML=events.map(e=>`<div class="calendar-event"><div class="calendar-when">${e[0]}<br>${e[1]} UTC</div><div><b>${e[2]}</b><small>Consensus, previous, actual and post-release reaction would be captured here.</small></div><span class="impact-badge">${e[3].toUpperCase()}</span></div>`).join('')}
document.getElementById('fundamentalRows').innerHTML=drivers.map(d=>`<div class="driver"><span>${d[0]}</span><b class="${d[1]==='Mixed'?'amber':d[1]==='Unknown'?'':'positive'}">${d[1]}</b><small>${d[2]}</small></div>`).join('');
renderPriority();renderNews();renderEvents();
function toast(msg){const t=document.getElementById('toast');t.textContent=msg;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2600)}
function go(page){document.querySelectorAll('.page').forEach(p=>p.classList.toggle('active',p.id==='page-'+page));document.querySelectorAll('.nav-item[data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));const label={dashboard:'Overview',news:'News intelligence',analysis:'Gold analysis',setups:'Trade setups',calendar:'Economic calendar',briefings:'Daily briefings',performance:'Performance lab',settings:'Data connections'};document.getElementById('crumbPage').textContent=label[page]||'Overview';document.getElementById('sidebar').classList.remove('open');window.scrollTo(0,0)}
document.querySelectorAll('.nav-item[data-page]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.page)));document.querySelectorAll('[data-goto]').forEach(b=>b.addEventListener('click',()=>go(b.dataset.goto)));document.querySelectorAll('#newsFilters button').forEach(b=>b.addEventListener('click',()=>{document.querySelectorAll('#newsFilters button').forEach(x=>x.classList.remove('selected'));b.classList.add('selected');renderNews()}));document.getElementById('categoryFilter').addEventListener('change',renderNews);document.getElementById('dismissNotice').addEventListener('click',()=>document.querySelector('.notice').remove());document.getElementById('refreshBtn').addEventListener('click',()=>loadLiveNews(true));document.getElementById('newsRefresh').addEventListener('click',()=>loadLiveNews(true));document.getElementById('notifyBtn').addEventListener('click',enableAlerts);document.getElementById('briefingBtn').addEventListener('click',()=>toast('Demo briefing generated. Live sourced research is not connected.'));document.getElementById('mobileMenu').addEventListener('click',()=>document.getElementById('sidebar').classList.toggle('open'));
function tick(){const d=new Date();document.getElementById('clock').textContent=d.toISOString().slice(11,19)+' UTC'}tick();setInterval(tick,1000);


// Live public-news aggregation via the same-origin serverless /api/news endpoint.
// GDELT articles are treated as developing leads, not verified facts.
function classifyStory(title='') {
  const t=title.toLowerCase();
  if (/federal reserve|\bfed\b|powell|fomc|interest rate/.test(t)) return 'Federal Reserve';
  if (/trump|white house|congress|election|tariff|sanction/.test(t)) return 'US Politics';
  if (/iran|israel|ukraine|russia|war|missile|military|middle east|conflict/.test(t)) return 'Geopolitics';
  if (/cpi|inflation|payroll|jobs report|employment|pce|gdp|unemployment/.test(t)) return 'US Economy';
  if (/treasury|bond yield|dollar|\bdxy\b/.test(t)) return 'Dollar & Bonds';
  return 'Gold & Global Markets';
}
function storyImportance(title='') {
  const t=title.toLowerCase();
  if (/breaking|emergency|attack|invasion|war|ceasefire|fomc|rate decision|powell|cpi|nonfarm|payroll|sanction/.test(t)) return 'high';
  if (/trump|fed|treasury|inflation|iran|israel|ukraine|tariff|dollar|gold/.test(t)) return 'medium';
  return 'low';
}
function storyImpact(title='') {
  const t=title.toLowerCase();
  if (/fed|powell|fomc|interest rate|inflation|cpi|pce|payroll/.test(t)) return 'Potentially relevant through expected Fed policy, real yields and the US dollar. Direction depends on the surprise versus expectations and the market response.';
  if (/iran|israel|ukraine|russia|war|missile|military|sanction|conflict/.test(t)) return 'Potential safe-haven channel. Gold reaction depends on escalation, duration, oil, the dollar and Treasury yields; bullish impact is not automatic.';
  if (/trump|white house|congress|tariff|trade/.test(t)) return 'Potentially relevant through trade, fiscal, policy and geopolitical expectations, with effects transmitted through the dollar and yields.';
  if (/treasury|bond yield|dollar|\bdxy\b/.test(t)) return 'Direct cross-asset watch: compare the direction and speed of dollar and yield moves with gold before assigning a bias.';
  return 'Potential gold relevance needs to be assessed against the dollar, real yields, Fed expectations and live XAU/USD price action.';
}
function notifyNewStories(items) {
  if (!alertsEnabled || !('Notification' in window) || Notification.permission!=='granted') return;
  items.filter(n=>n.level==='high').slice(0,3).forEach(n=>{
    if (liveStoryIds.has(n.id)) return;
    new Notification('AURUM AI · Important gold-related news',{body:n.title,tag:n.id});
  });
}
async function loadLiveNews(manual=false) {
  const refresh=document.getElementById('newsRefresh');
  if (refresh) refresh.disabled=true;
  try {
    const res=await fetch('/api/news',{headers:{'Accept':'application/json'},cache:'no-store'});
    if (!res.ok) throw new Error(`News endpoint returned ${res.status}`);
    const payload=await res.json();
    const articles=Array.isArray(payload.articles)?payload.articles:[];
    const mapped=articles.filter(a=>a.title && a.url).map(a=>{
      const title=String(a.title).slice(0,300), url=String(a.url);
      const id=String(a.id||url);
      const published=a.publishedAt?new Date(a.publishedAt):null;
      const time=published && !Number.isNaN(published.getTime())?published.toISOString().slice(11,16)+' UTC':'Time unavailable';
      const category=classifyStory(title), level=storyImportance(title);
      return {id,title,url,time,status:'developing',level,category,source:a.source||'GDELT-indexed report',summary:'Live article discovered by the global news monitor. This is a developing report and has not yet been independently corroborated by AURUM AI.',impact:storyImpact(title),grade:'C',statusText:'Developing · corroboration pending'};
    });
    const fresh=mapped.filter(n=>!liveStoryIds.has(n.id));
    mapped.forEach(n=>liveStoryIds.add(n.id));
    news=[...mapped,...demoNews];
    renderPriority();renderNews();
    const pill=document.querySelector('.demo-pill');
    if(pill){pill.innerHTML='<span></span> LIVE NEWS · GDELT';pill.classList.add('live-feed-pill');}
    const system=document.querySelector('.system-card');
    if(system) system.innerHTML='<span class="pulse"></span><div><b>News feed connected</b><small>GDELT · refreshing every 5 minutes</small></div>';
    const notice=document.querySelector('.notice');
    if(notice){notice.querySelector('b').textContent='Live news aggregation enabled';notice.querySelector('span:not(.notice-icon)').textContent='GDELT-indexed headlines are live. Articles remain developing leads until corroborated. Prices, chart analysis, X monitoring and trade levels are not connected.';}
    notifyNewStories(fresh);
    if(manual) toast(`${mapped.length} live news items retrieved. Social and market feeds still need API connections.`);
  } catch(err) {
    if(manual) toast('Live news is unavailable right now. Demo data remains visible.');
    console.error('AURUM live news:',err);
  } finally {if(refresh) refresh.disabled=false;}
}
async function enableAlerts(){
  if(!('Notification' in window)){toast('This browser does not support web notifications.');return;}
  const permission=await Notification.requestPermission();
  if(permission==='granted'){alertsEnabled=true;toast('Browser alerts enabled while AURUM AI is open.');new Notification('AURUM AI alerts enabled',{body:'Important gold-related news alerts are active while this website is open.'});}
  else toast('Notification permission was not granted.');
}
loadLiveNews(false);
setInterval(()=>loadLiveNews(false),5*60*1000);
