// Vercel serverless function: public GDELT news aggregation.
// No API key is required for the public GDELT DOC endpoint.
// GDELT discovery is not source verification; the UI labels these as developing reports.
module.exports = async function handler(req, res) {
  if (req.method !== 'GET') return res.status(405).json({ error: 'Method not allowed' });
  const query = '(gold OR XAU OR "Federal Reserve" OR Powell OR Trump OR tariffs OR Iran OR Israel OR Ukraine OR sanctions OR "Treasury yields" OR "US dollar" OR inflation OR FOMC)';
  const params = new URLSearchParams({
    query,
    mode: 'ArtList',
    format: 'json',
    maxrecords: '75',
    timespan: '24h',
    sort: 'DateDesc'
  });
  try {
    const upstream = await fetch(`https://api.gdeltproject.org/api/v2/doc/doc?${params.toString()}`, {
      headers: { 'User-Agent': 'AURUM-AI-NewsMonitor/0.1' },
      signal: AbortSignal.timeout(12000)
    });
    if (!upstream.ok) return res.status(502).json({ error: 'News provider temporarily unavailable' });
    const data = await upstream.json();
    const seen = new Set();
    const articles = (Array.isArray(data.articles) ? data.articles : []).filter(a => {
      if (!a.url || !a.title || !/^https?:\/\//i.test(a.url)) return false;
      const key = a.url.split('#')[0];
      if (seen.has(key)) return false;
      seen.add(key);
      return true;
    }).map(a => ({
      id: a.url,
      title: String(a.title).slice(0, 300),
      url: a.url,
      source: a.domain || a.sourcecountry || 'GDELT indexed source',
      publishedAt: parseGdeltDate(a.seendate),
      language: a.language || null,
      sourceCountry: a.sourcecountry || null
    }));
    res.setHeader('Cache-Control', 's-maxage=120, stale-while-revalidate=300');
    return res.status(200).json({ provider: 'GDELT DOC 2.0', fetchedAt: new Date().toISOString(), articles });
  } catch (error) {
    return res.status(502).json({ error: 'Unable to retrieve live news at this time' });
  }
};
function parseGdeltDate(value) {
  if (!value || !/^\d{8}T\d{6}$/.test(value)) return null;
  return `${value.slice(0,4)}-${value.slice(4,6)}-${value.slice(6,8)}T${value.slice(9,11)}:${value.slice(11,13)}:${value.slice(13,15)}Z`;
}
